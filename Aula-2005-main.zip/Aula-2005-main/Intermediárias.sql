#1. Mostre os alunos que possuem nota maior que 8
SELECT * FROM Matriculas
WHERE nota > 8;

#2. Liste os alunos que tiveram mais de 5 faltas
SELECT * FROM Matriculas
WHERE faltas > 5;

#3. Exiba os cursos com carga horária igual a 80 horas
SELECT * FROM Cursos
WHERE carga_horaria = 80;

#4. Mostre os alunos que NÃO moram em São Paulo
SELECT * FROM Alunos
WHERE cidade != 'São Paulo';

#5. Liste os alunos cujo nome começa com a letra “A”
SELECT * FROM Alunos
WHERE nome LIKE 'A%';

#6. Exiba os alunos cujo nome termina com a letra “a”
SELECT * FROM Alunos
WHERE nome LIKE '%a';

#7. Liste os cursos cujo nome contenha a palavra “Dados”
SELECT * FROM Cursos
WHERE nome_curso LIKE '%Dados%';

#8. Mostre as matrículas com nota entre 7 e 9
SELECT * FROM Matriculas
WHERE nota BETWEEN 7 AND 9;

#9. Liste os alunos que possuem exatamente 20 anos
SELECT * FROM Alunos
WHERE idade = 20;

#10. Exiba os cursos com carga horária menor ou igual a 60 horas
SELECT * FROM Cursos
WHERE carga_horaria <= 60;