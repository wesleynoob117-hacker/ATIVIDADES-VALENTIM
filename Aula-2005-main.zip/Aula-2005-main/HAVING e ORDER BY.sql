#1. Liste as cidades que possuem mais de 2 alunos
SELECT cidade, COUNT(*) AS quantidade_alunos
FROM Alunos
GROUP BY cidade
HAVING COUNT(*) > 2;

#2. Exiba os cursos cuja média de notas seja maior que 8
SELECT id_curso, AVG(nota) AS media_notas
FROM Matriculas
GROUP BY id_curso
HAVING AVG(nota) > 8;

#3. Mostre os cursos que possuem mais de 2 matrículas
SELECT id_curso, COUNT(*) AS quantidade_matriculas
FROM Matriculas
GROUP BY id_curso
HAVING COUNT(*) > 2;

#4. Liste os alunos cuja soma de faltas seja maior que 5
SELECT id_aluno, SUM(faltas) AS total_faltas
FROM Matriculas
GROUP BY id_aluno
HAVING SUM(faltas) > 5;

#5. Exiba os cursos cuja menor nota seja maior que 6
SELECT id_curso, MIN(nota) AS menor_nota
FROM Matriculas
GROUP BY id_curso
HAVING MIN(nota) > 6;

#6. Mostre os cursos ordenados pela carga horária em ordem decrescente
SELECT * FROM Cursos
ORDER BY carga_horaria DESC;

#7. Liste os alunos ordenados por idade do maior para o menor
SELECT * FROM Alunos
ORDER BY idade DESC;

#8. Exiba a média de notas por curso ordenada da maior para a menor
SELECT id_curso, AVG(nota) AS media_notas
FROM Matriculas
GROUP BY id_curso
ORDER BY media_notas DESC;

#9. Mostre as cidades ordenadas pela quantidade de alunos
SELECT cidade, COUNT(*) AS quantidade_alunos
FROM Alunos
GROUP BY cidade
ORDER BY quantidade_alunos DESC;

#10. Liste os alunos com média de notas maior que 7 ordenados pela média decrescente
SELECT id_aluno, AVG(nota) AS media_notas
FROM Matriculas
GROUP BY id_aluno
HAVING AVG(nota) > 7
ORDER BY media_notas DESC;