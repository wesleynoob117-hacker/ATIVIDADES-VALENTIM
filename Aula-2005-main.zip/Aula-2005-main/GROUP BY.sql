#1. Mostre quantos alunos existem em cada cidade
SELECT cidade, COUNT(*) AS quantidade_alunos
FROM Alunos
GROUP BY cidade;

#2. Exiba a média de idade dos alunos agrupada por cidade
SELECT cidade, AVG(idade) AS media_idade
FROM Alunos
GROUP BY cidade;

#3. Mostre a quantidade de matrículas por curso
SELECT id_curso, COUNT(*) AS quantidade_matriculas
FROM Matriculas
GROUP BY id_curso;

#4. Exiba a média das notas por curso
SELECT id_curso, AVG(nota) AS media_notas
FROM Matriculas
GROUP BY id_curso;

#5. Mostre o total de faltas agrupado por curso
SELECT id_curso, SUM(faltas) AS total_faltas
FROM Matriculas
GROUP BY id_curso;

#6. Liste a maior nota obtida em cada curso
SELECT id_curso, MAX(nota) AS maior_nota
FROM Matriculas
GROUP BY id_curso;

#7. Exiba a menor nota registrada em cada curso
SELECT id_curso, MIN(nota) AS menor_nota
FROM Matriculas
GROUP BY id_curso;

#8. Mostre a soma total das faltas agrupadas por aluno
SELECT id_aluno, SUM(faltas) AS total_faltas
FROM Matriculas
GROUP BY id_aluno;

#9. Exiba a média de notas agrupada por aluno
SELECT id_aluno, AVG(nota) AS media_notas
FROM Matriculas
GROUP BY id_aluno;

#10. Mostre quantos alunos existem em cada faixa etária
SELECT idade, COUNT(*) AS quantidade_alunos
FROM Alunos
GROUP BY idade;
