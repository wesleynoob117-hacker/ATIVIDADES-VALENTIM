-- buscar por produto dentro da venda
-- query - select - LEITURA
-- * == TODAS AS COLUNAS 
-- SELECT "NOMES DAS TABELAS" == FILTRO
SELECT id_produto,preco_unitario
from ITEM_VENDA
where id_venda = 1 and id_produto =1;
-- pesquisando por nome
SELECT iv.preco_unitario,p.nome_produto
from ITEM_VENDA as iv -- AS=APELIDO
JOIN PRODUTO as p ON iv.id_produto = p.id_produto-- JUNTAR
WHERE iv.id_venda = 1 and p.nome_produto LIKE'%CAFE%';
-- buscando todas as vendas de um cliente
SELECT 
    *
FROM
    VENDA
WHERE
    id_cliente = 1;
-- buscar produto mais vendido
SELECT 
    p.NOME_PRODUTO, SUM(iv.quantidade_item) AS Total_vendido
FROM
    ITEM_VENDA AS iv
        JOIN
    PRODUTO p ON p.id_produto = iv.id_produto
GROUP BY p.nome_produto;


