insert into CLIENTE (nome_cliente,email_cliente)
values
('CAMILE', 'C@MILE'),
('WESLEY', 'WE$LEY');
-- produtos
insert into PRODUTO(nome_produto,preco_produto)
values
('CAFE',300.00),
('PAO',20.00);
-- vendas
insert into VENDA(data_venda,id_cliente)
value
('2025-01-01',1),
('2024-05-05',2);
-- item_venda
insert into ITEM_VENDA(id_venda,id_produto,quantidade_item,preco_unitario)
value
(1,1,2,300.00),
(2,2,1,20.00);
