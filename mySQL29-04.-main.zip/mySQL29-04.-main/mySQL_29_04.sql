create database CINEMA;
use CINEMA;

create table CLIENTE(
id_cliente int primary key auto_increment,
nome_cliente varchar(100) not null,
cpf_cliente varchar(15) not null unique,
email_cliente varchar(30) not null unique,
status_cliente enum('ativo','inativo')
);
create table CATEGORIA(
id_categoria int primary key auto_increment,
descricao_cat varchar(30) not null
);
create table FILME(
id_filme int primary key auto_increment,
nome_filme varchar(100) not null,
faixa_etaria int check(faixa_etaria>=0),
duracao_filme int not null, -- em minutos
status_filme enum('em cartaz','fora de cartaz'),
id_categoria_filme int not null,
foreign key(id_categoria_filme)
references CATEGORIA(id_categoria)
);
CREATE TABLE SALA (
    id_sala INT PRIMARY KEY AUTO_INCREMENT,
    descricao_sala TEXT NOT NULL,
    tipo_sala ENUM('2D', '30', 'IMAX') DEFAULT '2D',
    capacidade_sala INT NOT NULL CHECK (capacidade_sala > 0),
    vip_sala BOOLEAN DEFAULT FALSE
);
CREATE TABLE SESSAO (
    id_sessao INT PRIMARY KEY AUTO_INCREMENT,
    data_hora DATETIME NOT NULL,
    status_sessao ENUM('aberta', 'encerrada', 'cancelada') DEFAULT 'aberta',
    id_sala_sessao INT,
    FOREIGN KEY (id_sala_sessao)
        REFERENCES SALA (id_sala),
    id_filme_sessao INT,
    FOREIGN KEY (id_filme_sessao)
        REFERENCES sala (id_sala),
   UNIQUE (data_hora , id_sala)
);
CREATE TABLE tipo_ingresso (
    id_tipo_ingresso INT PRIMARY KEY AUTO_INCREMENT,
    descricao_ingresso VARCHAR(50) NOT NULL,
    valor_ingresso DECIMAL(5 , 2 ) NOT NULL CHECK (valor_ingresso >= 0)
);
create table pedido(
id_pedido int primary key auto_increment,
data_hora datetime default current_timestamp,
id_cliente int,
status_pedido enum('aberto','pago','cancelado') default 'aberto',
foreign key(id_cliente) references CLIENTE(id_cliente)
);
CREATE TABLE ingresso (
    id_ingresso INT PRIMARY KEY AUTO_INCREMENT,
    id_pedido INT NOT NULL,
    id_sessao INT NOT NULL,
    id_tipo_ingresso INT NOT NULL,
    valor_pago DECIMAL(5 , 2 ) NOT NULL,
    status_ingresso ENUM('reservado', 'pago', 'cancelado') DEFAULT 'reservado',
    FOREIGN KEY (id_tipo_ingresso)
        REFERENCES TIPO_INGRESSO (id_tipo_ingresso),
    FOREIGN KEY (id_pedido)
        REFERENCES PEDIDO (id_pedido),
    FOREIGN KEY (id_sessao)
        REFERENCES SESSAO (id_sessao)
);

