create database SISTEMA;
use SISTEMA;

create table CLIENTE(
id_cliente int auto_increment primary key,
nome_cliente varchar(100) not null,
email_cliente varchar(30) not null unique
);
create table PRODUTO(
id_produto int auto_increment primary key,
nome_produto varchar(100) not null,
preco_produto decimal(5,2) not null
);
create table VENDA(
id_venda int auto_increment primary key,
data_venda date not null,
id_cliente int,
foreign key(id_cliente)
references CLIENTE(id_cliente)
);
CREATE TABLE ITEM_VENDA (
    id_venda INT,
    id_produto INT,
    quantidade_item INT NOT NULL,
    preco_unitario DECIMAL(5 , 2 ) NOT NULL,
    PRIMARY KEY (id_venda , id_produto),
    FOREIGN KEY (id_venda)
        REFERENCES VENDA (id_venda),
    FOREIGN KEY (id_produto)
        REFERENCES PRODUTO (id_produto)
);


